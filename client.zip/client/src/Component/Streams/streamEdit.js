import React from 'react'

const streamEdit = () => {
    return(
        <div>
            streamEdit
        </div>
    )
}

export default streamEdit