import React from 'react'

const streamShow = () => {
    return(
        <div>
            streamShow
        </div>
    )
}

export default streamShow