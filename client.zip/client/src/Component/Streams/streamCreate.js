import React from 'react'

const streamCreate = () => {
    return(
        <div>
            streamCreate
        </div>
    )
}

export default streamCreate