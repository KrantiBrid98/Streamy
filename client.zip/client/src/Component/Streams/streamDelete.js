import React from 'react'

const streamDelete = () => {
    return(
        <div>
            streamDelete
        </div>
    )
}

export default streamDelete