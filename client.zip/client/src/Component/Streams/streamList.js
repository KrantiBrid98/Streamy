import React from 'react'

const streamList = () => {
    return(
        <div>
            streamList
        </div>
    )
}

export default streamList