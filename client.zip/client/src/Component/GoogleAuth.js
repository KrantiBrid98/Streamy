import React, { Component } from "react";

class GoogleAuth extends Component {
    state = {
        isSignedIn: null
    }
    componentDidMount() {
        window.gapi.load('client:auth2', () => {
            // callback fun which will be called only when loading is done which takes time
            window.gapi.client.init({
                // init gives us a promise saying that the librabry has been successfully initialised
                clientId: '232809248903-qototto8def7lp9konmr056v52c72772.apps.googleusercontent.com',
                scope: 'email'
            }).then(() => {
                this.auth = window.gapi.auth2.getAuthInstance()
                this.setState({
                    isSignedIn: this.auth.isSignedIn.get()
                })
                this.auth.isSignedIn.listen(this.changeSignedStatus)
            })
        })
    }

    // listens if the user signs out and updates the state immediates and not only in refreshing the page
    changeSignedStatus = () => {
        this.setState({
            isSignedIn: this.auth.isSignedIn.get()
        })
    }

    renderAuth() {
        if (this.state.isSignedIn === null) {
            return <div>Null</div>
        } else if (this.state.isSignedIn === true) {
            return <div>Signed in</div>
        } else {
            return <div>Not signed</div>
        }
    }


    render() {
        return (
            <div>
                {this.renderAuth()}
            </div>
        )
    }
}

export default GoogleAuth;